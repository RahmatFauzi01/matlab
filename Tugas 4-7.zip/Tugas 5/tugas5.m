data = xlsread('datalinear.xlsx');
suhu = xlsread('datalinear.xlsx', 'B2:B31');
jcacat = xlsread('datalinear.xlsx', 'C2:C31');
x = input('Inputkan Nilai X = ');

for i=1 : length (data)
    x2=(suhu.^2);
    hasilx=x2;  
end

for i=1 : length (data)
    y2=(jcacat.^2);
    hasily=y2;  
end

for i=1 : length (data)
    xy=(suhu.*jcacat);
    hasilxy=xy;  
end

%Jumlahkan semua pada setiap tabel
totalx = sum(suhu);
totaly = sum(jcacat);
totalx2 = sum(hasilx);
totaly2 = sum(hasily);
totalxy = sum(hasilxy);
n = length (data);

%Menghitung Konstanta A
a = ((totaly.*totalx2)-(totalx.*totalxy))/((n.*totalx2)-(totalx.^2));

%Menghitung Koefisien Regresi B
b = ((30.*totalxy)-(totalx.*totaly))/((n.*totalx2)-(totalx.^2));

%Buat Model Persamaan Regresi
fprintf('Konstanta A = %g\n',a);

fprintf('Koefisien B = %g\n\n',b);

disp('Model Persamaan Regresi Linear Sederhana');
y = a+(b.*x);
fprintf('Y = %g + %gX\n',a,b);
fprintf('Y = %g + %g x %g\n',a,b,x);
fprintf('Y = %g',y);


