data = xlsread('datacustomer.xlsx');
disp(data);

umur = xlsread('datacustomer.xlsx', 'A2:A7');
pendapatan = xlsread('datacustomer.xlsx', 'B2:B7');
class = xlsread('datacustomer.xlsx', 'C2:C7');

umur_x=input('Masukkan Umur : ');
pendapatan_y=input('Masukkan Pendapatan : ');
k=input('Masukkan k : ');

for i=1 : length (data)

    x=(umur-umur_x);
    absolutx=abs(x);
    hasilUmur=absolutx.^2;
    
    y=(pendapatan-pendapatan_y);
    absoluty=abs(y);
    hasilPendapatan=absoluty.^2;
    
    hasil=sqrt(hasilUmur+hasilPendapatan);
    
end

disp('Hasil Sebelum DiSorting');
disp(hasil);
hasil = sort(hasil);

for j = 1:k
    tempK(j,1) = hasil(j);
end

disp('Hasil Setelah DiSorting & Ditampilkan Sebanyak K');
disp(tempK);