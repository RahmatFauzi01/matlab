data = xlsread('data.xlsx','B2:C11');
k=input('Inputkan Banyak Centroid = ');

x1 = randi([30,40], [k,1]);
x2 = randi([20,50], [k,1]);

centroid=[x1 x2];
kondisi = 1;
for i=1:k
    eval(sprintf('cen%d = [];',i'));
end
terasi=1;
dekat = zeros(length(data),1);
while kondisi ==1
    disp('Iterasi ke')
    disp(terasi)
    jarak=[];
    terdekat=[];
    for i=1:length(data)
        euc=[];
        for j=1:k
            x1=data(i,1)-centroid(j,1);
            x2=data(i,2)-centroid(j,2);
            x1=abs(x1)^2;
            x2=abs(x2)^2;
            jumlah=x1+x2;
            euc=[euc sqrt(jumlah)];
        end
        jarak=[jarak;euc];
        for j=1:k
            if min(euc)==euc(j)
                dekat=j;
                cen=[data(i,1) data(i,2)];
                eval(sprintf('cen = [cen%d;cen];',j));
                eval(sprintf('cen%d = cen;',j));
            end
        end
        terdekat = [terdekat;dekat];
    end     
    terdekat
    centBaru=[];
    for j=1:k
        eval(sprintf('cen = cen%d;',j));
        eval(sprintf('m%d = mean(cen);',j));
        eval(sprintf('centBaru = [centBaru;m%d];',j));
    end
    centroid
    centBaru
    if terdekat == dekat
        disp('Berhenti di iterasi ke')
        disp(terasi)
        kondisi = 0;
    else
        dekat=terdekat;
        centroid=centBaru;
    end
    terasi=terasi+1;
end