data = xlsread('berganda.xlsx');
X1 = xlsread('berganda.xlsx', 'A2:A13');
X2 = xlsread('berganda.xlsx', 'B2:B13');
Y = xlsread('berganda.xlsx', 'C2:C13');
n = length (data);

%Perulangan untuk memangkatkan data yang diperlukan 
for i=1 : length (data)
    X1p2=(X1.^2);
end

for i=1 : length (data)
    X2p2=(X2.^2);
end

for i=1 : length (data)
    Yp2=(Y.^2);
end

for i=1 : length (data)
    X1Y=(X1.*Y);
end

for i=1 : length (data)
    X2Y=(X2.*Y);
end

for i=1 : length (data)
    X1X2=(X1.*X2);
end


%Mencari Sigma Dari Tiap Data Part 1
sigX1 = sum(X1);
sigX2 = sum(X2);
sigY = sum(Y);
sigX1p2 = sum(X1p2);
sigX2p2 = sum(X2p2);
sigYp2 = sum(Yp2);
sigX1Y = sum(X1Y);
sigX2Y = sum(X2Y);
sigX1X2 = sum(X1X2);


%Mencari Sigma Dari Tiap Data Part 2
sigx1p2 = sigX1p2-((sigX1.^2)/n);
sigx2p2 = sigX2p2-((sigX2.^2)/n);
sigyp2 = sigYp2-((sigY.^2)/n);
sigx1y = sigX1Y-((sigX1.*sigY)/n);
sigx2y = sigX2Y-((sigX2.*sigY)/n);
sigx1x2 = sigX1X2-((sigX1.*sigX2)/n);


%Mencari b1, b2, a
b1 = ((sigx2p2.*sigx1y)-(sigx1x2.*sigx2y))/((sigx1p2.*sigx2p2)-(sigx1x2.^2));
b2 = ((sigx1p2.*sigx2y)-(sigx1x2.*sigx1y))/((sigx1p2.*sigx2p2)-(sigx1x2.^2));
a = (sigY./n)-(b1.*(sigX1./n))-(b2.*(sigX2./n));

%Output
disp('Regresi Linear Berganda 2 Variabel');
fprintf('A = %g\n',a);
fprintf('B1 = %g\n',b1);
fprintf('B2 = %g',b2);